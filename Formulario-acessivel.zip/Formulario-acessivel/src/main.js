import VoiceAssistant from './components/VoiceAssistant.js';

const body = document.querySelector('body');

// config
const language = 'pt-br';
const rate = 1.0;
const volume = 1.0;

const voiceAssistant =  new VoiceAssistant(language, rate, volume);

body.addEventListener('click', (e) => {

    const clickedElement = e.target;
    const tag = clickedElement.tagName;
    
    if(tag === 'IMG') {
       
        const previousElement = clickedElement.parentNode
        

        if(previousElement.tagName === 'BUTTON'){

            let previousDiv = previousElement.parentNode
            let previousInput = previousDiv.parentNode.children[0]
            let value = previousInput.value.trim();
            
            if( value != ""){
                voiceAssistant.readInput(value)
            }else {
                voiceAssistant.readInput("Campo vazio")
            }

            return;
        }

        const labelText = previousElement.textContent;
        voiceAssistant.readLabel(labelText)

    } else if(tag === 'BUTTON') {
        let buttonContent = clickedElement.textContent;
        voiceAssistant.readLabel(buttonContent)
    } else if (tag === 'INPUT') {
        let opcaoRadio = clickedElement.value;
        clickedElement.type === "radio" ? voiceAssistant.readLabel(opcaoRadio) : ''
    }
})

body.addEventListener('mouseover', e => {
    const mouseElement = e.target;
    const tag = mouseElement.tagName;

    if(tag === 'BUTTON') {
        let buttonContent = mouseElement.textContent;
        voiceAssistant.readLabel(buttonContent)
        
    }
})